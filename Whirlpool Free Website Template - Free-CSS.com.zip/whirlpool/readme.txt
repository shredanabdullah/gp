======================================================================

	  Website Template Name: Whirlpool
	  Website Template URI: http://www.templates.com/preview/website-templates/wt-8410.html
	  Version: 1
	  Author: Templates.com Team
	  Author URI: http://www.templates.com

======================================================================


   +++ Be sure to visit TEMPLATES.com for more website templates, 3D models, +++
   +++               illustrations and other products!                       +++


   +++ License +++

   Whirlpool website template is 100% FREE!  We kindly ask you to
   leave the footer links intact.  Thank you so much! :)



   +++ INSTALLATION & EDITING +++

   - Copy all the files from the 'site' directory to the appropriate (usually 'www' or      'public_html') directory on your hosting. That's it.
   - This template may be edited with any HTML editor. If you do not know where to get one      you may consider trying NotePad++. It can be downloaded at notepad-plus.sourceforge.net      and it's free.



   +++ HOW TO PUT YOUR OWN LOGO & TAGLINE +++

   - You need to replace logo.jpg (it is located in site>images>logo.jpg) with your own .gif      file. It is recommended that you logo.gif should be 237X40 pixels.
   - To add your own tagline you need to replace slogan.jpg (it is located in      site>images>slogan.jpg). Recommended size is 437X22 pixels.
